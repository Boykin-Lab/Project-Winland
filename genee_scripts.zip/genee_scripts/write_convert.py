import pandas as pd 
import numpy as np 
import sys

traits = ['MCV_norm','Platelet_norm', 'Height_norm', 'BMI_norm', 'DBP_norm', 'SBP_norm', 'WBC_norm', 'RBC_norm', 'Hemoglobin_norm', 'Hematocrit_norm', 'MCH_norm', 'MCHC_norm', 'Lymphocyte_norm', 'Monocyte_norm', 'Neutrophil_norm', 'Eosinophil_norm', 'Basophil_norm','Urate_norm','HBA1C_norm','EGFR_norm','CRP_norm','Triglyceride_norm','HDL_norm','LDL_norm','Cholesterol_norm']

for trait in traits:
	for chrom in range(1,23):
		bim = pd.read_csv('../1.ldfiles/ukb_chr' + str(chrom) + '.filtered.bim',delim_whitespace = True,names = ['A','snp','i','B','a1','a2'])
		#change path below to the gwas output
		df = pd.read_csv('../../2.imputed_ukb_data/1.gwas/outputs/british/' + trait + '.' + str(chrom) + '.' + trait + '.glm.linear',delim_whitespace = True)[['#CHROM','POS','ID','BETA']]
		df = df.rename(columns = {'ID':'snp'})
		merged = bim.merge(df,on = 'snp',how = 'inner')
		# print(merged)
		merged['snp'].to_csv('genee_snps_british_chr' + str(chrom) + '.txt',sep = '\t',index = False,header = False)
		merged[['#CHROM','snp','POS','BETA']].to_csv('british/' + trait + '.' + str(chrom) + '.genee.input.txt',header = None,index = False, sep = '\t')

