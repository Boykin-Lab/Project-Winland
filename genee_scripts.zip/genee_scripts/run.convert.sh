#!/bin/bash
#SBATCH -n 1
#SBATCH --mem=4G
#SBATCH --mail-type=ALL
#SBATCH --time=72:00:00
#SBATCH --mail-user=samuel_smith1@brown.edu
#SBATCH --array=111-660
#SBATCH --account=ccmb-condo
module load R/3.4.0
module load plink/2.00
sh convert_files/convert$SLURM_ARRAY_TASK_ID.sh

