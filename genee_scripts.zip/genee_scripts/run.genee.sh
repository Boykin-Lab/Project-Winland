#!/bin/bash
#SBATCH -n 1
#SBATCH --mem=32G
#SBATCH --mail-type=ALL
#SBATCH --time=72:00:00
#SBATCH --mail-user=samuel_smith1@brown.edu
#SBATCH --array=1-550
sh british/genee$SLURM_ARRAY_TASK_ID.sh
