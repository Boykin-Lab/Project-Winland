args = commandArgs(trailingOnly=TRUE)
cohort = args[1]
chr = args[2]
trait = args[3]
mydata = read.table(paste(cohort,"/",trait,".",chr,".genee.input.25.txt",sep=""),header = FALSE)
#mydata=mydata[mydata$V1 == chr,]
row.names(mydata) = c()
#head(mydata)
save(mydata,file = paste(cohort,"/",trait,"_",chr,"_betas_25.RData",sep=""))

