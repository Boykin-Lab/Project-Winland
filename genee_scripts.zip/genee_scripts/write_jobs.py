import numpy as np 
import pandas as pd 
import sys

traits = ['MCV_norm','Platelet_norm', 'Height_norm', 'BMI_norm', 'DBP_norm', 'SBP_norm', 'WBC_norm', 'RBC_norm', 'Hemoglobin_norm', 'Hematocrit_norm', 'MCH_norm', 'MCHC_norm', 'Lymphocyte_norm', 'Monocyte_norm', 'Neutrophil_norm', 'Eosinophil_norm', 'Basophil_norm','Urate_norm','HBA1C_norm','EGFR_norm','CRP_norm','Triglyceride_norm','HDL_norm','LDL_norm','Cholesterol_norm']

for ancestry in ['british',]:
	counter = 1
	for trait in traits:
		for chrom in range(1,23):
			newfile = open(ancestry + '/genee' + str(counter) + '.sh', 'w')
			newfile.write('#!/bin/bash\n#SBATCH -n 1\n#SBATCH --mem=10G\n#SBATCH --mail-type=ALL\n#SBATCH --time=72:00:00\n#SBATCH --mail-user=samuel_smith1@brown.edu\nmodule load R/3.4.3\nmodule load plink/2.00\n')
			# newfile.write('Rscript genee_script.R ' + ancestry + ' ' + str(chrom) + ' ' + trait + '\n')
			newfile.write('Rscript genee_script_25.R ' + ancestry + ' ' + str(chrom) + ' ' + trait)
			counter+=1
 	      
# newfile = open('run.genee.sh','w')
# newfile.write('#!/bin/bash\n#SBATCH -n 1\n#SBATCH --mem=10G\n#SBATCH --mail-type=ALL\n#SBATCH --time=72:00:00\n#SBATCH --mail-user=samuel_smith1@brown.edu\nmodule load R/3.4.3\nmodule load plink/2.00\n')
#for sample in range(1,51):
#	newfile.write('sh subsample' + str(sample) + '/genee$SLURM_ARRAY_TASK_ID.sh\n')
# for ancestry in ['british','indian','african']:
# 	newfile.write('sh ' + ancestry + '/genee$SLURM_ARRAY_TASK_ID.sh\n')
