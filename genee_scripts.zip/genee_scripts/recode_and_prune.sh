#!/bin/bash
#SBATCH -n 1
#SBATCH -t 300:00:00
#SBATCH --mem=128G
#SBATCH --mail-type=ALL
#SBATCH --array=1-22



module load plink/1.90
plink --bfile ukb_chr$SLURM_ARRAY_TASK_ID --indep-pairwise 100 10 0.5 --out british_chr$SLURM_ARRAY_TASK_ID
plink --bfile ukb_chr$SLURM_ARRAY_TASK_ID --extract ukb_chr$SLURM_ARRAY_TASK_ID.prune.in --make-bed --out ukb_chr$SLURM_ARRAY_TASK_ID.filtered
plink --bfile ukb_chr$SLURM_ARRAY_TASK_ID.filtered --r square --out ukb_chr$SLURM_ARRAY_TASK_ID.filtered
Rscript Convert_plink_ld_R.R ukb $SLURM_ARRAY_TASK_ID

rm ukb_chr$SLURM_ARRAY_TASK_ID.ld
