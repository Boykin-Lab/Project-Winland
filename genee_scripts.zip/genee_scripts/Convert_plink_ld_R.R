args = commandArgs(trailingOnly=TRUE)
cohort = args[1]
chr = args[2]
ld = read.table(paste(cohort,"_chr",chr,".ld",sep=""))
save(ld,file = paste(cohort,"_chr",chr,".RData",sep=""))